$(function (){
    console.log( 'I`m ready' );
})